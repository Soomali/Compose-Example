package com.mehmetali.pati

import android.util.Log
import org.junit.Test

import org.junit.Assert.*

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
interface CommentData{
    val subComments:MutableList<SubComment>

}
data class Comment(
    val text:String,
    override val subComments: MutableList<SubComment> = mutableListOf()
):com.mehmetali.pati.CommentData
data class SubComment(
    val text: String,
    override val subComments: MutableList<SubComment> = mutableListOf(),
val isVisible:Boolean = true
):com.mehmetali.pati.CommentData


class ExampleUnitTest {
    val items:MutableList<Comment> = mutableListOf()
    fun createDummyCommentData() {
        val com1 = getDummyComment("1")
        val com2 = getDummyComment("2")
        com2.subComments.add(getDummySubComment())
        val sb1 = getDummySubComment("1s")
        val sb2 = getDummySubComment("2s")
        addSubCommentForDepth(sb2, 1,5,2)
        com1.subComments.addAll(
            listOf(sb1,sb2)
        )
        items.add(com1)
        items.add(1,com2)
        println(items.first().text)
        println(items.last().text)
    }
    private fun addSubCommentForDepth(comment:SubComment,itemSize:Int,depth:Int,startVisibility:Int = depth + 1){

        if(depth != 0) {
            comment.subComments.addAll(List(itemSize){ getDummySubComment("$depth", startVisibility > 0) })
            for(i in comment.subComments){
                addSubCommentForDepth(
                    i,itemSize,depth - 1, startVisibility - 1
                )
            }
        }
    }

    private fun getDummyComment(text:String = "hey"):Comment{
        return Comment(text)
    }
    private fun getDummySubComment(data:String = "hey",isVisible:Boolean = true):SubComment{
        return SubComment( data,isVisible = isVisible)
    }

    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }
    // 0 - 5
    @Test
    fun getSubCommentCountTest(){
        this.createDummyCommentData()
        assertEquals(4,getSubCommentCount(items.first() as CommentData))
        assertEquals(1,getSubCommentCount(items.last() as CommentData))
        assertEquals(0,getSubCommentCount(items.first().subComments[0]))
        assertEquals(2,getSubCommentCount(items.first().subComments[1]))
        assertEquals(0,getSubCommentCount(items.last().subComments[0]))
    }
    @Test
    fun getCommentTest(){
        this.createDummyCommentData()
        assertEquals(items[0],getComment(0,items as MutableList<CommentData>))
        assertEquals(items[0].subComments[0],getComment(1,items as MutableList<CommentData>))
        assertEquals(items[0].subComments[1],getComment(2,items as MutableList<CommentData>))
        assertEquals(items[0].subComments[1].subComments[0],getComment(3,items as MutableList<CommentData>))
        assertEquals(items[0].subComments[1].subComments[0].subComments[0],getComment(4,items as MutableList<CommentData>))
        assertEquals(items[1],getComment(5,items as MutableList<CommentData>))
    }
    @Test
    fun triey(){
        var x:Boolean? = true
        printx(x)
        x = false
        printx(x)
        x = null
        printx(x)
    }
    fun printx(x:Boolean?){
        when(x){
            true -> println("x is $x")
            false -> println("x is $x")
            else -> println("x is null")
        }
    }

    private fun getComment(position: Int,items:MutableList<CommentData>): CommentData {
        if (position == 0) return items[0]
        var i = 1
        var count = getSubCommentCount(items[0]) + 1
        var beforeCount = 0
        while (position - count >= 0) {
            beforeCount = count
            count +=  getSubCommentCount(items[i]) + 1
            i++
        }
        return if(position - beforeCount == 0) items[i - 1]
        else getComment(position - beforeCount - 1,items[i - 1].subComments as MutableList<CommentData>)
    }

    private fun getSubCommentCount(comment: CommentData):Int {
        val value = comment.subComments.filter { it.isVisible }
        var cnt = 0
        if(value.isNullOrEmpty()) return cnt
        cnt += value.size
        for(i in value){
            cnt += getSubCommentCount(i)
        }
        return cnt
    }

}