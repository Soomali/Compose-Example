package com.mehmetali.pati.data.client

import android.graphics.*
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.GeoPoint
import com.mehmetali.pati.data.entities.*
import com.mehmetali.pati.data.entities.dataObjects.SelfUser


fun createAnimal(data:Map<String,Any>,reference: DocumentReference,positions:List<GeoPoint>) =
    Animal(id = reference,seenLocations =positions,
        lastSeenBy = data["lastseenby"] as DocumentReference,lastSeen =(data["lastseen"] as Timestamp).toDate(),
        behaviour = data["behaviour"] as Double,condition = data["condition"] as Double)


fun createUser(userData:MutableMap<String,Any>, isSelf:Boolean = false,documentReference: DocumentReference): User {
        val name = userData["name"] as String
        val photoUrl = userData["photoUrl"] as String
        val bio = userData["bio"] as String

        Log.d("[userData]","$userData")
        val userType:UserType = UserType.values()[(userData["usertype"] as Long).toInt()]
        if(!isSelf){
            return User(
                id = documentReference, name = name, photo = photoUrl,
                bio = bio, userType = userType,
            )
        }
            return User(id = documentReference,name = name,photo = photoUrl,
                bio = bio,userType = userType, privacySettings = MutableLiveData(),
                blocked = MutableLiveData(),
                favoriteAnimals = MutableLiveData(),
            comments = listOf())

    }


fun createComment(reference:DocumentReference,data:Map<String,Any?>,user:DocumentReference):Comment =
    Comment(reference,data["text"] as String,user,(data["date"] as Timestamp).toDate(),
        data["likes"] as Long,data["dislikes"] as Long,data["username"] as String,data["photo"] as String )
fun createSubComment(reference: DocumentReference, data: Map<String, Any?>, user:DocumentReference,place:Int):SubComment =
    SubComment(id = reference,
        text = data["text"] as String,
        user = user,
        date = (data["date"] as Timestamp).toDate(),
        likes = data["likes"] as Long,
        dislikes = data["dislikes"] as Long,
        place = place,
        username = data["username"] as String,
        photo = data["photo"] as String,
    isVisible = place < 4)

fun getSubCommentCount(comment:CommentData,filtered:Boolean = true):Int {
    val value = if(filtered) comment.subComments.value?.filter { it.isVisible } else comment.subComments.value
    var cnt = 0
    if(value.isNullOrEmpty()) return cnt
    cnt += value.size
    for(i in value){
        cnt += getSubCommentCount(i,filtered)
    }
    return cnt
}

//depth being -1 meaning set visibility of all the subComments.
//with given depth, subComments that is not connected to comments within the depth
//will not be effected.
fun setVisibilityOfSubComments(comment:SubComment,visibility:Boolean = true,depth:Int = -1){
    if (comment.subComments.value.isNullOrEmpty() || depth == 0) return
    for (i in comment.subComments.value!!) {
        Log.d("[SVOSC Simple]", i.text)
        i.isVisible = visibility
        setVisibilityOfSubComments(i,visibility,depth - 1)
    }
}


fun getCircularBitmap(bitmap: Bitmap): Bitmap {
    val output: Bitmap = if (bitmap.width > bitmap.height) {
        Bitmap.createBitmap(bitmap.height, bitmap.height, Bitmap.Config.ARGB_8888)
    } else {
        Bitmap.createBitmap(bitmap.width, bitmap.width, Bitmap.Config.ARGB_8888)
    }
    val canvas = Canvas(output)
    val color = -0xbdbdbe
    val paint = Paint()
    var path = Path()
    path.fillType = Path.FillType.EVEN_ODD
    path.moveTo((bitmap.width *0.15).toFloat(),(bitmap.height * 0.25).toFloat())
    //to bottom point
    path.lineTo((bitmap.width * 0.5).toFloat(),bitmap.height.toFloat(),)
    //to right point
    path.lineTo((bitmap.width *0.7).toFloat(),(bitmap.height* 0.25).toFloat())
    path.close()

    val redPaint = Paint()
    redPaint.color = Color.RED
    redPaint.textSize = 30f
    redPaint.style = Paint.Style.FILL_AND_STROKE
    canvas.drawPath(path,redPaint)

    val rect = Rect(0, 0, bitmap.width, bitmap.height)
    var r = 0f
    val c = (bitmap.width *0.45).toFloat()
    r = if (bitmap.width > bitmap.height) {
        (bitmap.height *0.35).toFloat()
    } else {
        (bitmap.width *0.35).toFloat()
    }
    paint.isAntiAlias = true
    canvas.drawARGB(0, 0, 0, 0)

    paint.color = color

    canvas.drawCircle(c, c, r, paint)
    paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
    canvas.drawBitmap(bitmap, rect, rect, paint)


    return output
}


fun blockUser(blocked:DocumentReference,callBack:(() -> Unit)?){
    SelfUser.self.value!!.id!!.collection("BlockedUsers").document(blocked.id).set("blocked" to true).addOnSuccessListener {
        callBack?.invoke()
    }
}
fun unBlockUser(blocked: DocumentReference,callBack: (() -> Unit)?){
    SelfUser.self.value!!.id!!.collection("BlockedUsers").document(blocked.id).delete().addOnSuccessListener {
         callBack?.invoke()

    }
}


