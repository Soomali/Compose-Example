package com.mehmetali.pati.ui.fragmentHolder.ui.profile.comments

import android.content.Intent
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.MutableLiveData
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.firestore.DocumentReference
import com.mehmetali.pati.R
import com.mehmetali.pati.data.entities.dataObjects.AnimalHolder
import com.mehmetali.pati.data.entities.dataObjects.SelfUser
import com.mehmetali.pati.databinding.CommentsFragmentBinding
import com.mehmetali.pati.ui.animalDetail.AnimalDialog
import com.mehmetali.pati.ui.fragmentHolder.ui.map.MapViewModel

class CommentsFragment(private val user:DocumentReference) : Fragment() {

    companion object {
        fun newInstance(user: DocumentReference) = CommentsFragment(user)
    }

    private lateinit var viewModel: CommentsViewModel
    private var _binding: CommentsFragmentBinding? = null
    private val binding get() = _binding!!
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = CommentsFragmentBinding.inflate(layoutInflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = CommentsViewModel(user)
        val adapter = ProfileCommentAdapter { onClickToAnimal(it) }

        val layoutManager = LinearLayoutManager(requireContext())
        binding.profileCommentView.adapter = adapter
        binding.profileCommentView.layoutManager = layoutManager
        viewModel.commentData.observe(viewLifecycleOwner, {
            if (binding.progressView.progressBar.visibility != View.GONE) {
                binding.progressView.progressBar.visibility = View.GONE
            }
            adapter.addNewItems(it)
        })
    }

    private fun onClickToAnimal(animal: DocumentReference) {
        viewModel.postToAnimalHolder(
            animal
        )
        AnimalHolder.animal.observe(viewLifecycleOwner, { _ ->

            val intent = Intent(requireContext(), AnimalDialog::class.java)
            startActivity(intent)
        })

    }
}