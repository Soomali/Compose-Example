package com.mehmetali.pati.ui.fragmentHolder.ui.profile

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore
import com.mehmetali.pati.data.client.createUser
import com.mehmetali.pati.data.entities.User

class ProfileViewModel:ViewModel() {
    val userData = MutableLiveData<User>()
    fun postRef(userRef:DocumentReference){
        userRef.get().addOnSuccessListener {
            val user = createUser(it.data!!,false,it.reference)
            userData.postValue(user)
        }
    }
}