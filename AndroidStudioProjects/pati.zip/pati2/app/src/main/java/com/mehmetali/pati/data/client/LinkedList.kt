package com.mehmetali.pati.data.client

import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.MutableLiveData
import com.mehmetali.pati.data.entities.AnimalPhoto
import java.lang.Exception

class OrderedLinkedList(photos: MutableLiveData<MutableList<AnimalPhoto>>, owner: LifecycleOwner? = null,) {
    private var startNode: AnimalPhotoNode? = null
    var size:Int = 0
    val isEmpty get() = startNode == null
    private var current = 0
    val next:AnimalPhoto get()=
        getAt(current++)

    val previous:AnimalPhoto get() {
        if(current < 0) return startNode!!.value
        return getAt(current--)
    }
    private fun init(value:MutableList<AnimalPhoto>){
        size = value.size
        startNode = AnimalPhotoNode(value.first(),null)
        for (i in 1 until value.size){
            addPhoto(value[i])
        }

    }
    init {
        init(photos.value!!)
        if(owner != null) {photos.observe(owner,{
            init(it)
        })}
    }
    fun addPhoto(photo:AnimalPhoto){
        if(startNode == null || photo.votes > startNode!!.value.votes){
            val node = AnimalPhotoNode(photo,startNode)
            startNode = node
        }
        else {
            var next: AnimalPhotoNode? = startNode!!.next
            var before = startNode!!
            while (next != null && next.value.votes > photo.votes){
                before = next
                next = next.next
            }
            before.next = AnimalPhotoNode(photo,next)

        }
        size++
    }
    fun getAt(position:Int):AnimalPhoto{
        var node: AnimalPhotoNode? = startNode
        var index = position
        while (node != null && index > 0){
            node = node.next
            index--
        }
        if(index == 0 && node != null) return node.value
        throw Exception("IndexOutOfBoundsException: tried to reach $index. element of the list with size $size")
    }


    data class AnimalPhotoNode(var value:AnimalPhoto,var next: AnimalPhotoNode?)

}