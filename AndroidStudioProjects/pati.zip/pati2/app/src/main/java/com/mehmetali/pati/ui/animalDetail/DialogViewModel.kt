package com.mehmetali.pati.ui.animalDetail

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.graphics.Color
import android.util.Log
import android.view.View
import android.widget.LinearLayout
import androidx.core.content.ContextCompat
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearSmoothScroller
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.mehmetali.pati.R
import com.mehmetali.pati.data.client.createComment
import com.mehmetali.pati.data.client.createSubComment
import com.mehmetali.pati.data.entities.*
import com.mehmetali.pati.data.entities.dataObjects.AnimalHolder
import com.mehmetali.pati.data.entities.dataObjects.SelfUser
import com.mehmetali.pati.databinding.CommentLayoutBinding

class DialogViewModel(private val requestFocus:() -> Unit,private val manager: LinearLayoutManager,private var smoothScroller: LinearSmoothScroller):ViewModel() {
    var commentParent:Pair<CommentData,Int>? = null
    var beforeCommentLayout:CommentLayoutBinding? = null
    var commentSendStatus = MutableLiveData<Pair<CommentData,Int>>()
    var lastQuery:Pair<Animal,Timestamp>? = null
    val likedNamesID:MutableLiveData<List<DocumentReference>> by lazy {
        MutableLiveData<List<DocumentReference>>().also {
            getNameVoteData()
        }}
    var lastNameVote = 0
    val likedCommentsId : MutableLiveData<List<LikeDataHolder>> by lazy{
        MutableLiveData<List<LikeDataHolder>>().also {
            getLikedCommentsOfAnimal()
        }
    }
    fun seeAnimal(callBack:(() -> Unit)? = null){
        val animal = AnimalHolder.animal.value!!
        val self = SelfUser.self.value!!
        if(animal.lastSeenBy != self.id){
            if(animal.seenLocations.size >= 5) {
            }
            animal.id.update("lastseenby",SelfUser.self.value!!.id!!).addOnSuccessListener {
                callBack?.invoke()
            }
        }
    }
    private fun getLikedCommentsOfAnimal(){
        Log.d("[CalledDataOf]","...")
        val animal = AnimalHolder.animal.value!!
        val votesCol = SelfUser.self.value!!.id!!.collection("Votes")
        var query = votesCol.whereEqualTo("animal",animal.id).orderBy("date", Query.Direction.ASCENDING).limit(
            SelfUser.commentLimit)
        if(lastQuery != null && animal == lastQuery!!.first){
            query = query.whereGreaterThan("date",lastQuery!!.second)
        }
        query.get().addOnSuccessListener {
            Log.d("[GLCOA data]","${it.documents.size}")
            if(it.documents.isNotEmpty()){
                lastQuery = animal to it.documents.last().data!!["date"] as Timestamp
                likedCommentsId.postValue(
                    it.documents.map {tit ->
                        LikeDataHolder(tit.reference,tit.data!!["isLiked"] as Boolean,tit.data!!["comment"] as DocumentReference)
                    }
                )
            }
        }.addOnCompleteListener {
            Log.d("[GLCOA data]","finished, cancelled:${it.isCanceled}, complete:${it.isComplete},error:${it.exception},success:${it.isSuccessful},")
        }
    }

    companion object{

        fun handleLikeEvent(comment:CommentData,like:Boolean?,view: View,animal:DocumentReference? = null){
        val data:MutableMap<String,Any> = mutableMapOf(
            "animal" to  (animal ?: AnimalHolder.animal.value!!.id),
            "comment" to comment.id,
            "date" to Timestamp(comment.date),
            "isLiked" to true
        )
        val self = SelfUser.self.value!!
        val votesCol = self.id!!.collection("Votes")
        val query = votesCol.whereEqualTo("comment",comment.id)

        comment.id.update(mapOf("likes" to comment.likes,
            "dislikes" to comment.dislikes))
        when(like){
            true -> {
                query.get().addOnSuccessListener {
                    if(it.documents.size == 0){
                        votesCol.add(data).addOnCompleteListener {tit ->
                            Log.d("[VOADD]","success:${tit.isSuccessful},cancelled:${tit.isCanceled}, complete:${tit.isComplete},error:${tit.exception},")
                        }
                    }
                    else{
                        it.documents.first().reference.set(data)
                    }
                    view.isEnabled = true
                }.addOnCompleteListener {tit ->
                    Log.d("[VOADDLIKEFIN]","success:${tit.isSuccessful},cancelled:${tit.isCanceled}, complete:${tit.isComplete},error:${tit.exception},")
                }
            }
            false -> {
                query.get().addOnSuccessListener {
                    data["isLiked"] = false
                    if(it.documents.size == 0){
                        votesCol.add(data).addOnCompleteListener {tit ->
                            Log.d("[VOADDDL]","success:${tit.isSuccessful},cancelled:${tit.isCanceled}, complete:${tit.isComplete},error:${tit.exception},")

                        }
                    }
                    else{
                        it.documents.first().reference.set(data)
                    }
                    view.isEnabled = true
                }.addOnCompleteListener { tit->
                    Log.d("[VOADDDLFIN]","success:${tit.isSuccessful},cancelled:${tit.isCanceled}, complete:${tit.isComplete},error:${tit.exception},")

                }
            }
            else -> {
                query.get().addOnSuccessListener {
                    it.documents.firstOrNull()?.reference?.delete()
                    view.isEnabled = true
                }
            }
        }

    }
        fun handleVoteEvent(name:AnimalName,like: Boolean,view: View){
            view.isEnabled = false

            name.id.update("points",name.vote)
            if(like){
                SelfUser.self.value!!.id!!.collection("AnimalNameVotes").add(
                    hashMapOf(
                        "animal" to AnimalHolder.animal.value!!.id,
                        "name" to name.id
                    )
                ).addOnSuccessListener {
                    view.isEnabled = true
                }
            }else{
                SelfUser.self.value!!.id!!.collection("AnimalNameVotes").
                whereEqualTo("name",name.id).
                get().
                addOnSuccessListener {
                    it.documents.firstOrNull()?.reference?.delete()
                    view.isEnabled = true
                }
            }
        }
    }

    private fun changeColorOfComment(commentBinding: CommentLayoutBinding,from: Int,to:Int){
        val anim = ValueAnimator()
        anim.setIntValues(from,to)
        anim.setEvaluator(ArgbEvaluator())
        anim.addUpdateListener {
            commentBinding.comment.setBackgroundColor(it.animatedValue as Int)

        }
        anim.duration = 400L
        anim.start()
    }
    fun unFocus(){
        if (beforeCommentLayout != null) changeColorOfComment(beforeCommentLayout!!,Color.CYAN,Color.WHITE)
        beforeCommentLayout = null
        commentParent = null

    }
    fun focusAt(comment:CommentData,position:Int,commentBinding: CommentLayoutBinding){

        if (beforeCommentLayout != null) changeColorOfComment(beforeCommentLayout!!,Color.CYAN,Color.WHITE)
        changeColorOfComment(commentBinding,Color.WHITE,Color.CYAN)
        beforeCommentLayout = commentBinding

        requestFocus()

        commentParent = comment to position
        smoothScroller.targetPosition = position

        manager.startSmoothScroll(smoothScroller)
    }
    fun commentTo(text:String){
        if(beforeCommentLayout != null) changeColorOfComment(beforeCommentLayout!!,Color.CYAN,Color.WHITE)
        val user = SelfUser.self.value!!
        val data = mutableMapOf(
            "date" to Timestamp.now(),
            "likes" to 0L,
            "dislikes" to 0L,
            "text" to text,
            "user" to user.id,
            "username" to user.name,
            "photo" to user.photo
        )
        Log.d("[DVM(ct)]","$commentParent")
        Log.d("[DVM(ct) commentPrPL]","${(commentParent?.first as? SubComment)?.place}")
        if(commentParent != null){
            commentParent!!.first.id.collection("Comments").add(
                data
            ).addOnSuccessListener {
                val place  = (commentParent!!.first as? SubComment)?.place
                val newPlace = if(place != null) place + 1 else 1
                Log.d("[DVM(ct) newComPLC]","${(commentParent?.first as? SubComment)?.place}")

                val subCom = createSubComment(it,data,
                    user.id!!, newPlace)
                commentSendStatus.postValue(subCom to commentParent!!.second)

            }
        }else {
                AnimalHolder.animal.value!!.id.collection("Comments").add(
                data
            ).addOnSuccessListener {
                val com = createComment(it,data,user.id!!)
                commentSendStatus.postValue(com to -1)
            }
        }
    }

   private fun getNameVoteData() {
       SelfUser.self.value!!.id!!.collection("AnimalNameVotes").
       whereEqualTo("animal",AnimalHolder.animal.value!!.id).
       orderBy("votes").
       limit(30).
       whereGreaterThanOrEqualTo("votes",lastNameVote).get().addOnSuccessListener {
            val names = mutableListOf<DocumentReference>()
            for (i in it.documents){
                val data = i.data!!
                names.add(data["name"] as DocumentReference)
            }
           likedNamesID.postValue(names)
       }.addOnCompleteListener {
           Log.d("[GNMVD]","${it.isCanceled} ${it.exception}")
       }
   }

}