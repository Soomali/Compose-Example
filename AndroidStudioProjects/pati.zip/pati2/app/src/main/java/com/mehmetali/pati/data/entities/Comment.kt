package com.mehmetali.pati.data.entities

import androidx.lifecycle.MutableLiveData
import com.google.firebase.firestore.DocumentReference
import com.mehmetali.pati.data.entities.dataObjects.SelfUser
import java.util.*








interface CommentData {
    val username:String
    val photo:String
    val id: DocumentReference
    val text: String
    val user: DocumentReference
    val date: Date
    var likes: Long
    var dislikes: Long
    var likedByUser:Boolean?
    var subComments: MutableLiveData<MutableList<SubComment>>
    var blocked:Boolean
}

data class Comment(
    override val id: DocumentReference,
    override val text:String,
    override val user:DocumentReference,
    override val date: Date,
    override var likes:Long,
    override var dislikes:Long,
    override val username: String,
    override val photo: String,
    override var blocked:Boolean = false,
    override var likedByUser:Boolean? = null,
    override var subComments: MutableLiveData<MutableList<SubComment>>  = MutableLiveData(),

    ):CommentData


data class SubComment(
   override val id : DocumentReference,
   override val text: String,
   override val user: DocumentReference,
   override val date: Date,
   override var likes:Long,
   override var dislikes: Long,
   val place:Int,
   override val username: String,
   override val photo: String,
   override var blocked:Boolean = false,
   override var likedByUser:Boolean? = null,
   var isVisible:Boolean = true,
   override var subComments: MutableLiveData<MutableList<SubComment>> =MutableLiveData(),

   ):CommentData