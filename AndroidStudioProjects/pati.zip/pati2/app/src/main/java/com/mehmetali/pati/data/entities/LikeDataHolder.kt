package com.mehmetali.pati.data.entities

import com.google.firebase.firestore.DocumentReference

data class LikeDataHolder(
    val id:DocumentReference,
    var isLike:Boolean,
    val comment:DocumentReference
){
    override fun equals(other: Any?): Boolean {
        return other is LikeDataHolder && other.id == id
    }
}
