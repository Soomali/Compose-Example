package com.mehmetali.pati.ui.signUp

import android.graphics.Bitmap
import com.mehmetali.pati.data.entities.User
import com.mehmetali.pati.data.entities.UserType

object SignUpUserData {
    var email:String = ""
    var name:String = ""
    var bio:String = ""
    var photo: Bitmap? = null
    var password:String = ""
    fun getUser(): User {
        return User(name,bio,null,null,userType = UserType.NORMAL)
    }
}