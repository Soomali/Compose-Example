package com.mehmetali.pati.ui.splashScreen

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.firebase.auth.FirebaseAuth
import com.mehmetali.pati.data.entities.dataObjects.SelfUser
import com.mehmetali.pati.ui.fragmentHolder.FragmentHolderActivity
import com.mehmetali.pati.ui.login.LoginActivity

class SplashActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        auth = FirebaseAuth.getInstance()
        if(auth.currentUser != null){
            SelfUser.uid = auth.currentUser!!.uid
            val intent = Intent(applicationContext,FragmentHolderActivity::class.java)
            startActivity(intent)
        }else{
            val intent = Intent(applicationContext,LoginActivity::class.java)
            startActivity(intent)
        }
        finish()
    }
}