package com.mehmetali.pati.data.entities

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.versionedparcelable.VersionedParcelize
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.GeoPoint
import java.io.Serializable

@VersionedParcelize
data class Animal(
    val id: DocumentReference,
    val names:MutableLiveData<MutableList<AnimalName>> = MutableLiveData<MutableList<AnimalName>>(),
    val photos:MutableLiveData<MutableList<AnimalPhoto>> = MutableLiveData<MutableList<AnimalPhoto>>(),
    val seenLocations:List<GeoPoint>,
    val lastSeenBy: DocumentReference,
    val lastSeen: java.util.Date,
    var comments:MutableLiveData<MutableList<Comment>> = MutableLiveData<MutableList<Comment>>(),
    val behaviour:Double,
    val condition:Double
):Serializable

data class AnimalName(
    val id: DocumentReference,
    val suggestedUser:DocumentReference,
    val name:String,
    var vote:Long,
    var likedByUser:Boolean = false
)

data class AnimalPhoto(
    val putUser: DocumentReference,
    val votes:Long,
    val photo: String // might change to url later.
)

