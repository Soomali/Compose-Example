package com.mehmetali.pati.data.entities

import androidx.lifecycle.MutableLiveData
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.Exclude
import com.google.firebase.firestore.IgnoreExtraProperties
import java.time.LocalDate

enum class UserType {
    NORMAL,VETERINARIAN,ANIMAL_HELPER
}
data class Favorite(
    val animal:Animal,
    val date:LocalDate
)

@IgnoreExtraProperties
data class User(
    val name:String,
    val bio:String,
    val id:DocumentReference?,//it meaning null is user is not yet logged in,maybe wont.
    val photo: String?,//might change it to url later
    val privacySettings: MutableLiveData<PrivacySetting> = MutableLiveData(),
    val blocked: MutableLiveData<List<User>> =  MutableLiveData(),
    val favoriteAnimals:MutableLiveData<List<Favorite>> =  MutableLiveData(),
    val comments:List<Comment>?= null,
    val userType: UserType
){
    @Exclude
    fun toMap():Map<String,Any?>{
        return mapOf(
            "name" to name,
            "bio" to bio,
            "photoUrl" to photo,
            "userType" to userType
        )
    }

}


data class Location( // might user pre defined location class,it is a placeholder for now.
    val latitude: Double,
    val longitude:Double
)


