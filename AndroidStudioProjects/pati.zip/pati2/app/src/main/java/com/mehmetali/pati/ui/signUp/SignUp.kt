package com.mehmetali.pati.ui.signUp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.mehmetali.pati.R
import com.mehmetali.pati.databinding.ActivitySignUpBinding

/**
 *
 * [fragment A]
 * E-mail
 * Password
 *
 * [fragment B]
 * Name
 * [fragment B]
 * Bio
 *
 * [fragment C]
 * Photo
 *
 *
 */




class SignUp : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivitySignUpBinding.inflate(layoutInflater)
        setSupportActionBar(binding.signUpToolbar)
        setContentView(binding.root)
    }
}