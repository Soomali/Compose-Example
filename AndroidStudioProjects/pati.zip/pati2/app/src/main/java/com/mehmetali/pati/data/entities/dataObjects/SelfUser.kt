package com.mehmetali.pati.data.entities.dataObjects

import androidx.lifecycle.MutableLiveData
import com.google.firebase.firestore.DocumentReference
import com.mehmetali.pati.data.entities.User

object SelfUser {
    var uid:String? = null
    var self: MutableLiveData<User> = MutableLiveData()
    val isInitialized get() = self.value == null
    var shownUserUid:MutableLiveData<DocumentReference> = MutableLiveData()
    const val commentLimit = 60L

}