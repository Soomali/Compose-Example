package com.mehmetali.pati.ui.fragmentHolder.ui.profile

import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomViewTarget
import com.bumptech.glide.request.transition.Transition
import com.google.android.material.tabs.TabLayoutMediator
import com.mehmetali.pati.R
import com.mehmetali.pati.data.entities.User
import com.mehmetali.pati.data.entities.dataObjects.SelfUser
import com.mehmetali.pati.databinding.FragmentProfileBinding
import com.mikhaellopez.circularimageview.CircularImageView


val TAB_LABELS = listOf(
    "Beğendikleri",
    "Yorumlar"
)

class ProfileFragment : Fragment() {
    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!
    private val profileViewModel = ProfileViewModel()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(layoutInflater)

        return binding.root
    }
    private fun initUser(user: User = SelfUser.self.value!!){
            if(user.photo != null){
                Glide.with(this).
                asBitmap().
                load(user.photo).
                placeholder(R.drawable.ic_launcher_foreground).
                into(object: CustomViewTarget<CircularImageView, Bitmap>(binding.profileImage){
                    override fun onLoadFailed(errorDrawable: Drawable?) {
                        binding.profileImage.setImageDrawable(errorDrawable)
                    }
                    override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                        binding.profileImage.setImageBitmap(resource)
                    }
                    override fun onResourceCleared(placeholder: Drawable?) {
                        Log.d("[CA resourceCleared]","cleared ${user.name} photo.")
                    }
                })
            }else {
                binding.profileImage.setImageResource(R.drawable.ic_launcher_foreground)
            }
            binding.profileNameView.text = user.name
            binding.bioView.text = user.bio
    }


    private fun initOtherUser(){
        SelfUser.shownUserUid.observe(viewLifecycleOwner,{
            profileViewModel.postRef(it)
        })
        profileViewModel.userData.observe(viewLifecycleOwner,{
            initUser(it)
        })

    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        Log.d("[OVC]","${SelfUser.shownUserUid.value}")
        if (SelfUser.shownUserUid.value != null){
            initOtherUser()
        }else{
            initUser()
        }
        val adapter = ProfilePagerAdapter(requireActivity())
        binding.viewpager.adapter = adapter

        TabLayoutMediator(binding.tabLayout,binding.viewpager){tab,pos ->
            tab.text = TAB_LABELS[pos]
        }.attach()
    }

}