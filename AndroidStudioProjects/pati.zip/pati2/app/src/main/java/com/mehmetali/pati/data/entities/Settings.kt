package com.mehmetali.pati.data.entities

enum class PrivacyChoice {
    ONLY_FOLLOWERS,SELECTED,EVERYONE
}
data class PrivacySetting(
    val profileSetting: PrivacyChoice = PrivacyChoice.EVERYONE,
    val favoritesSetting: PrivacyChoice = PrivacyChoice.EVERYONE
)