package com.mehmetali.pati.ui.animalDetail

import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.MutableLiveData
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.mehmetali.pati.R
import com.mehmetali.pati.data.client.OrderedLinkedList
import com.mehmetali.pati.data.entities.AnimalPhoto
import com.mehmetali.pati.data.entities.dataObjects.SelfUser
import com.mehmetali.pati.databinding.AnimalDialogImageLayoutBinding

class ImageAdapter(owner:LifecycleOwner, photos: MutableLiveData<MutableList<AnimalPhoto>>, private val initialSize:Int = 1):
    RecyclerView.Adapter<ImageAdapter.ImageViewHolder>() {
    private val items = OrderedLinkedList(photos,owner)
    class ImageViewHolder(private val binding: AnimalDialogImageLayoutBinding) : RecyclerView.ViewHolder(binding.root) {
        private var isPutByUser:Boolean = false
        init{
            binding.animalImageView.scaleType = ImageView.ScaleType.FIT_XY

       }
        fun bind(photo:AnimalPhoto){
            isPutByUser = photo.putUser == SelfUser.self.value!!.id!!
            Glide.with(binding.animalImageView.context)
                .load(photo.photo)
                .apply(RequestOptions().placeholder(R.drawable.ic_launcher_foreground))
                .into(binding.animalImageView)
            binding.ShowOptionsButton.setOnClickListener {
                showPopup(it)
            }
        }
        private fun showPopup(view: View) {
            val popup = PopupMenu(view.context, view)
            popup.inflate(if(isPutByUser) R.menu.image_options_self_menu
                          else R.menu.image_options_menu
                         )

            popup.setOnMenuItemClickListener(PopupMenu.OnMenuItemClickListener { item: MenuItem? ->
                when (item!!.itemId) {
                    R.id.report -> {
                        Toast.makeText(view.context,"MAAAAAAAAAAAAA",Toast.LENGTH_LONG).show()
                    }
                    R.id.delete -> {
                        Toast.makeText(view.context,"DELETEEEEEEEEEEEEEEEEEEEEEEEE",Toast.LENGTH_LONG).show()
                    }
                }
                true
            })

            popup.show()
        }


    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImageViewHolder {
        val view = AnimalDialogImageLayoutBinding.inflate(LayoutInflater.from(parent.context))
        return ImageViewHolder(view)
    }

    override fun onBindViewHolder(holder: ImageViewHolder, position: Int) {
        holder.bind(items.getAt(position))
    }

    override fun getItemCount(): Int = if(items.isEmpty) initialSize else items.size

}