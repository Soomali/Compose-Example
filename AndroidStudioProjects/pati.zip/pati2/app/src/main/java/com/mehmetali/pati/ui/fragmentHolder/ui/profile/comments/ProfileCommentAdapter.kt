package com.mehmetali.pati.ui.fragmentHolder.ui.profile.comments

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.DocumentReference
import com.mehmetali.pati.data.entities.Comment
import com.mehmetali.pati.databinding.CommentLayoutBinding
import com.mehmetali.pati.ui.animalDetail.CommentViewHolder
import com.mehmetali.pati.ui.animalDetail.DialogViewModel


class ProfileCommentAdapter(private val onClickToAnimal:(DocumentReference) -> Unit): RecyclerView.Adapter<RecyclerView.ViewHolder>() {


    private val comments = mutableListOf<Pair<Comment,DocumentReference>>()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val commentLayoutBinding = CommentLayoutBinding.inflate(LayoutInflater.from(parent.context))
        commentLayoutBinding.answer.text = "Hayvana Git ->"
        return CommentViewHolder(commentLayoutBinding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val comment = comments[position]
        val commentHolder = (holder as CommentViewHolder)
            commentHolder.bind(comment.first,
            fun(like:Boolean?,view:View) {DialogViewModel.handleLikeEvent(comment.first,like,view,comment.second)},
                null,{

                },{

                },null)
        commentHolder.setAnswerOnClickListener {
            onClickToAnimal(comment.second)
        }
    }

    override fun getItemCount(): Int = comments.size

    fun addNewItems(items:Collection<Pair<Comment,DocumentReference>>){
        var isChanged = false
        for (i in items){
            if (!comments.contains(i)){
                isChanged = true
                comments.add(i)
            }
        }
        if (isChanged){
            notifyDataSetChanged()
        }
    }

}