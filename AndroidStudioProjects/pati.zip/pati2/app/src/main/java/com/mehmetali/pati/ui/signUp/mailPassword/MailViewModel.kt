package com.mehmetali.pati.ui.signUp.mailPassword

import android.util.Patterns
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.mehmetali.pati.R

class MailViewModel :ViewModel(){

    private val _signUpForm = MutableLiveData<SignUpFormState>()
    val signUpFormState: LiveData<SignUpFormState> = _signUpForm


    fun signUpDataChanged(username: String, password: String) {
        var emailError :Int? = null
        val passwordError:Int? = isPasswordValid(password)

        if (!isUserNameValid(username)) {
            emailError = R.string.invalid_username
        }

        _signUpForm.value = SignUpFormState(
            emailError,
            passwordError,
            isDataValid = passwordError == null && emailError == null )
    }

    // A placeholder username validation check
    private fun isUserNameValid(username: String): Boolean {
        return if (username.contains('@')) {
            Patterns.EMAIL_ADDRESS.matcher(username).matches()
        } else {
            false
        }
    }

    // A placeholder password validation check
    private fun isPasswordValid(password: String): Int? {
        return when(true){
          password.length < 8  -> R.string.invalid_password
          !Regex("\\d").containsMatchIn(password) -> R.string.invalid_password_no_digit
          !Regex("[A-Za-z]").containsMatchIn(password) -> R.string.invalid_password_no_character
            else -> null
        }

    }

    fun checkIfEmailExists(email:String,onComplete:(Boolean) -> Unit) {
        FirebaseAuth.getInstance().fetchSignInMethodsForEmail(email).addOnCompleteListener {
            onComplete(it.result.signInMethods != null && it.result.signInMethods!!.size == 0)
        }
    }

}