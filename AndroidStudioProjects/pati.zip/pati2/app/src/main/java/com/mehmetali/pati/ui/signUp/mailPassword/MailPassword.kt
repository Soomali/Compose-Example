package com.mehmetali.pati.ui.signUp.mailPassword

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import android.view.inputmethod.EditorInfo
import androidx.appcompat.widget.Toolbar
import androidx.navigation.fragment.findNavController
import com.mehmetali.pati.R
import com.mehmetali.pati.databinding.FragmentMailPasswordBinding
import com.mehmetali.pati.ui.login.afterTextChanged
import com.mehmetali.pati.ui.signUp.SignUpUserData

class MailPassword : Fragment() {
    private lateinit var binding:FragmentMailPasswordBinding
    private val mailViewModel = MailViewModel()
    private var fetchedEmail:String = ""
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        requireActivity().findViewById<Toolbar>(R.id.signUpToolbar).setNavigationOnClickListener {
            requireActivity().onBackPressed()
        }
        binding = FragmentMailPasswordBinding.inflate(layoutInflater)
        val email = binding.signUpEmail
        val password = binding.signUpPassword
        val nextButton = binding.nextButton
        nextButton.isEnabled = false
        mailViewModel.signUpFormState.observe(viewLifecycleOwner,{
            nextButton.isEnabled = it.isDataValid
            if(it.passwordError != null){
                password.error = getString(it.passwordError)
            }
            if (it.usernameError != null) {
                email.error = getString(it.usernameError)
            }
            })
        email.setOnFocusChangeListener{ _, hasFocus ->

            if (!hasFocus && fetchedEmail != email.text.toString()){
                        fetchedEmail = email.text.toString()
                        binding.emailFetchProgress.visibility = View.VISIBLE
                        email.isEnabled = false
                        mailViewModel.checkIfEmailExists(
                            email.text.toString(),
                        ){ tit ->
                            email.isEnabled = true
                            binding.emailFetchProgress.visibility = View.GONE
                            if (!tit){
                                email.error = "E-mail kullanımda"
                                if (nextButton.isEnabled){
                                    nextButton.isEnabled = false
                                }
                            }else if (mailViewModel.signUpFormState.value?.passwordError == null){
                                nextButton.isEnabled = true
                            }
                        }
                }
            }



        nextButton.setOnClickListener {
            SignUpUserData.email = email.text.toString()
            SignUpUserData.password = password.text.toString()
            val bundle = Bundle().apply {
                putInt("errorCodeLow",R.string.name_error_low)
                putInt("errorCodeHigh",R.string.name_error_high)
                putInt("hint",R.string.name_hint)
                putInt("limitLow",2)
                putInt("limit",50)
                putBoolean("goNextFragment",false)
            }

            findNavController().navigate(R.id.action_mailPassword_to_additionalData,bundle)
        }
        email.afterTextChanged {
            postToViewModel()
        }
        password.afterTextChanged {
            postToViewModel()
        }
        return binding.root
    }

    private fun postToViewModel() = mailViewModel.signUpDataChanged(
        username = binding.signUpEmail.text.toString(),
        password = binding.signUpPassword.text.toString()
    )

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                activity?.onBackPressed()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

}
