package com.mehmetali.pati.data.entities.dataObjects

import android.graphics.Bitmap
import android.util.Log
import com.google.firebase.firestore.DocumentReference

object CommentPhotoResolver {
    private val photos: MutableMap<DocumentReference, Bitmap> = mutableMapOf()
    fun contains(user:DocumentReference) = photos.containsKey(user)
    fun add(user:DocumentReference,bm:Bitmap) {
        Log.d("[CPR ADD]","contains:${contains(user)},$user, $photos")
        if (!contains(user)){
            photos[user] = bm
        }
    }
    fun get(user:DocumentReference):Bitmap?{
        Log.d("[CPR GET]","$user,${photos[user]}")
        return photos[user]
    }
}