package com.mehmetali.pati.ui.fragmentHolder.ui.map

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.os.Build
import androidx.fragment.app.Fragment

import android.os.Bundle
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.google.android.gms.location.*
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.mehmetali.pati.R
import com.mehmetali.pati.data.client.getCircularBitmap
import com.mehmetali.pati.data.entities.Animal
import com.mehmetali.pati.data.entities.FocusedMarkerState
import com.mehmetali.pati.data.entities.dataObjects.AnimalHolder
import com.mehmetali.pati.databinding.FragmentMapsBinding
import com.mehmetali.pati.ui.animalDetail.AnimalDialog
private const val PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 1

class MapsFragment : Fragment() {
    private var focusedMarker: FocusedMarkerState = FocusedMarkerState()
    private lateinit var mapViewModel:MapViewModel
    private lateinit var applicationContext: Context
    private var markers:HashMap<Animal, Pair<Marker?,MarkerOptions>> = hashMapOf()
    private lateinit var mMap: GoogleMap
    private lateinit var binding: FragmentMapsBinding
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback

    @SuppressLint("MissingPermission")
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        mapViewModel = MapViewModel()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity())
        fusedLocationClient.lastLocation.addOnSuccessListener {
                mapViewModel.postToUserPosition(it.latitude,it.longitude)
                mapViewModel.getSelf().observe(viewLifecycleOwner,{
                    Log.d("[UserData]","$it")
                })
        }
        applicationContext = requireActivity().applicationContext
            binding = FragmentMapsBinding.inflate(layoutInflater)
            //imageLoader.init(ImageLoaderConfiguration.createDefault(applicationContext))


            locationCallback = object:LocationCallback(){
                override fun onLocationResult(result: LocationResult) {

                    mapViewModel.postToUserPosition(result.lastLocation.latitude,result.lastLocation.longitude)

                    }
            }
            return binding.root
        }
    @RequiresApi(Build.VERSION_CODES.O)
    private val callback = OnMapReadyCallback { googleMap ->
            mMap = googleMap
            mMap.setMinZoomPreference(10.54561F)
            mapViewModel.getSelfPos().observe(this){ userPos ->
                mMap.moveCamera(CameraUpdateFactory.newLatLng(LatLng(userPos.latitude,userPos.longitude)))

                mapViewModel.getAnimals().observe(this,{
                   for (i in markers.keys) {
                        if(!it.contains(i)){
                            (markers[i] as Marker).remove()
                            markers.remove(i)
                        }
                    }

                    for (i in it) {
                        if(!markers.keys.contains(i) || markers[i] == null){
                            val animLatLng = LatLng(i.seenLocations[0].latitude,i.seenLocations[0].longitude)
                            val option = MarkerOptions().position(animLatLng)
                            Log.d("[HeHo]","${i.id}")
                            i.photos.observe(this, { photos ->
                                Log.d("[photoData]","${photos[0]}")
                                Glide.with(this).
                                asBitmap().
                                load( photos[0].photo).
                                into(object: CustomTarget<Bitmap>(){
                                    override fun onResourceReady(
                                        resource: Bitmap,
                                        transition: Transition<in Bitmap>?
                                    ) {

                                        val scale = 300
                                        val markerIcon = Bitmap.createScaledBitmap(resource,scale,scale,false)

                                        option.icon(BitmapDescriptorFactory.fromBitmap(getCircularBitmap(markerIcon)))
                                        markers[i] = Pair(mMap.addMarker(option),option)
                                    }
                                    override fun onLoadCleared(placeholder: Drawable?) {
                                        //Do nothing.
                                    }
                                })

                            }
                        )
                    }
                }
            })

            }
            mMap.setOnMarkerClickListener {
                if(focusedMarker.handleFocusedMarker(it)){
                    //handle showing animal dialog and data.for now it will fetch the comment data of the animal
                    lateinit var animal:Animal
                    Log.d("[DoubleClick on Marker]","$it")
                    for(i in markers.keys){
                        if (focusedMarker.isAnimalAssociated(markers[i]!!.first!!)){
                            animal = i
                            break
                        }
                    }
                    AnimalHolder.animal.value = animal
                    val intent = Intent(applicationContext, AnimalDialog::class.java)
                    startActivity(intent)


                }else{
                    mMap.animateCamera(CameraUpdateFactory.zoomTo(10f))
                    mMap.animateCamera(CameraUpdateFactory.newLatLng(it.position),object:GoogleMap.CancelableCallback {
                        override fun onFinish() {
                            //handle animation,etc..
                            if(!focusedMarker.hasFocused || focusedMarker.tryRefocus(it)){
                                focusedMarker.focus(it)

                                lateinit var animal:Animal
                                for(i in markers.keys) {
                                    if (markers[i]!!.first == it){
                                        animal = i
                                    } else {
                                        markers[i]!!.first?.isVisible = false
                                    }
                                }
                                AnimalHolder.animal.postValue( animal)
                                for(j in 1 until animal.seenLocations.size) {
                                    val i = animal.seenLocations[j]
                                    focusedMarker.addShadows(mMap.addMarker(markers[animal]!!.second.position(
                                        LatLng(i.latitude,
                                            i.longitude)
                                    )))


                                }
                            }
                        }

                        override fun onCancel() {
                            focusedMarker.removeFocus()
                        }

                    })
                }
                true
            }
            mMap.setOnCameraMoveListener{
                if(focusedMarker.hasFocused && focusedMarker.exceededLimit(mMap.cameraPosition.target)) {

                    focusedMarker.removeFocus()
                }
            }
        }


    @RequiresApi(Build.VERSION_CODES.O)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val mapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?
        mapFragment?.getMapAsync(callback)
    }

    @SuppressLint("MissingPermission")
    private fun startLocationUpdates() {
        val locationRequest = LocationRequest.create().apply {
            interval = 10000
            fastestInterval = 5000
            priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        }
        fusedLocationClient.requestLocationUpdates(locationRequest,locationCallback, Looper.getMainLooper())
    }

    // stop location updates
    private fun stopLocationUpdates() {
        fusedLocationClient.removeLocationUpdates(locationCallback)
    }

    // stop receiving location update when activity not visible/foreground
    override fun onPause() {
        super.onPause()
        stopLocationUpdates()
    }

    // start receiving location update when activity  visible/foreground
    override fun onResume() {
        super.onResume()
        startLocationUpdates()
    }


}