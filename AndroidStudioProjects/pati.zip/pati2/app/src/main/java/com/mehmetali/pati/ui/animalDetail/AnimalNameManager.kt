package com.mehmetali.pati.ui.animalDetail

import android.view.View
import android.widget.LinearLayout
import com.mehmetali.pati.data.entities.AnimalName
import com.mehmetali.pati.data.entities.dataObjects.AnimalHolder

class AnimalNameManager() {

    private var names:MutableList<AnimalName> = mutableListOf()
    fun addNews(items:Collection<AnimalName>){
        for (i in items){
            if (!names.contains(i)){
                names.add(i)
            }
        }
    }
    private var currentLast = 0
    var addCount = 4
    private val haveMore get() = currentLast < names.size


    private fun getMore():List<AnimalName>{
        var i = 0
        val holder = mutableListOf<AnimalName>()
        while(i < addCount && currentLast + i < names.size ){
            holder.add(names[currentLast + i])
            i++
        }
        currentLast += i
        return holder.toList().reversed()
    }
    fun addTo(view:LinearLayout,getView:(AnimalName,Int) -> View,onHaveMore:() -> Unit){
        val added = getMore()
        for (i in added.indices){
            view.addView((getView(added[i],i + currentLast)),0)
        }
        if (haveMore){
            onHaveMore()
        }
    }



}