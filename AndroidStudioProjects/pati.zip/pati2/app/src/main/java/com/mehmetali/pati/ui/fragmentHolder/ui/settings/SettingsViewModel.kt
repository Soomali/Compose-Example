package com.mehmetali.pati.ui.fragmentHolder.ui.settings

import androidx.lifecycle.ViewModel

class SettingsViewModel:ViewModel() {

}