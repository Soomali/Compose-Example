package com.mehmetali.pati.ui.fragmentHolder.ui.profile.comments

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.*
import com.mehmetali.pati.data.client.createAnimal
import com.mehmetali.pati.data.client.createComment
import com.mehmetali.pati.data.entities.AnimalPhoto
import com.mehmetali.pati.data.entities.Comment
import com.mehmetali.pati.data.entities.CommentData
import com.mehmetali.pati.data.entities.dataObjects.AnimalHolder

class CommentsViewModel(private val user:DocumentReference) : ViewModel() {
    val commentData :MutableLiveData<List<Pair<Comment,DocumentReference>>> by lazy {
        MutableLiveData<List<Pair<Comment,DocumentReference>>>().also {
            fetchCommentsOfUser()
        }
    }
    private val firebaseInstance = FirebaseFirestore.getInstance()
    fun fetchCommentsOfUser(){
        firebaseInstance.collectionGroup("Comments").whereEqualTo("user",user).limit(50).orderBy("date",
            Query.Direction.DESCENDING).get().addOnSuccessListener {
                    Log.d("[FCOU]","${it.documents.size}")
                   commentData.postValue(
                       it.documents.map { tit ->
                           createComment(tit.reference,tit.data!!,user) to getFurthestParent(tit.reference)
                       }
                   )
        }
    }
    fun postToAnimalHolder(animal:DocumentReference){
            animal.get().addOnSuccessListener {
                val seenPositions = it.data!!["seenPositions"] as List<HashMap<String,Any>>
                val seenPositionsGeoPoint = seenPositions.map { position ->
                    position["point"]
                } as List<GeoPoint>
                val anim = createAnimal(it.data!!,it.reference,seenPositionsGeoPoint)
                it.reference.collection("Photos").limit(5).orderBy("votes").get().addOnSuccessListener { tit ->
                    try {
                        val animalPhotos = mutableListOf<AnimalPhoto>()
                        for (i in tit.documents){
                            val data = i.data!!
                            val animalPhoto = AnimalPhoto(photo = data["photoUrl"] as String,votes = data["votes"] as Long,putUser = data["user"] as DocumentReference)
                            Log.d("[Photo]", tit.documents[0].data.toString())
                            animalPhotos.add(animalPhoto)
                        }
                        Log.d("[Animal Photo Data]","Posted")
                        anim.photos.postValue(animalPhotos)
                        AnimalHolder.animal.postValue(anim)
                    } catch (e:Exception) {
                        Log.e("[Error]","${e.localizedMessage}")
                    }
                }
            }


    }
    private fun getFurthestParent(ref:DocumentReference):DocumentReference{
        var refer:DocumentReference = ref
        while (refer.parent.parent != null){
            refer = refer.parent.parent!!
        }
        return refer
    }


}