package com.mehmetali.pati.ui.signUp.additionalData

import android.os.Bundle
import android.text.InputFilter
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.mehmetali.pati.R
import com.mehmetali.pati.databinding.FragmentAdditionalDataBinding
import com.mehmetali.pati.ui.login.afterTextChanged

private const val ERROR_CODE_LOW = "errorCodeLow"
private const val ERROR_CODE_HIGH = "errorCodeHigh"
private const val HINT = "hint"
private const val LIMIT_LOW = "limitLow"
private const val LIMIT = "limit"
private const val GO_NEXT_FRAGMENT = "goNextFragment"
class AdditionalData : Fragment() {
    private var errorCodeLow: Int? = null
    private var errorCodeHigh: Int? = null
    private var hint: Int? = null
    private var limitLow:Int? = null
    private var limit:Int? = null
    private var goNextFragment:Boolean? = null
    private lateinit var binding: FragmentAdditionalDataBinding
    private lateinit var additionalDataViewModel: AdditionalDataViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        arguments?.let {
            errorCodeLow = it.getInt(ERROR_CODE_LOW)
            errorCodeHigh = it.getInt(ERROR_CODE_HIGH)
            hint = it.getInt(HINT)
            limitLow = it.getInt(LIMIT_LOW,0)
            limit = it.getInt(LIMIT,255)
            goNextFragment = it.getBoolean(GO_NEXT_FRAGMENT)
            additionalDataViewModel =
            AdditionalDataViewModel(
                errorCodeLow!!,
                errorCodeHigh!!,
                limitLow!!,
                limit!!
            )
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentAdditionalDataBinding.inflate(layoutInflater)
        binding.additionalDataTextEdit.hint = getString(hint!!)
        binding.additionalDataNext.isEnabled = limitLow == 0
        binding.additionalDataTextEdit.maxLines = limit?.div(10) ?: 2
        binding.additionalDataTextEdit.filters += InputFilter.LengthFilter(limit ?: 255)
        binding.additionalDataTextEdit.afterTextChanged {
            additionalDataViewModel.setOnTextChangedData(it)
        }
        binding.additionalDataNext.setOnClickListener {
            if (!goNextFragment!!){
                val bundle = Bundle().apply {
                    putInt(ERROR_CODE_LOW,R.string.name_error_low)
                    putInt(ERROR_CODE_HIGH,R.string.bio_error_high)
                    putInt(HINT,R.string.bio_hint)
                    putInt(LIMIT,255)
                    putInt(LIMIT_LOW,0)
                    putBoolean(GO_NEXT_FRAGMENT,true)
                }
                findNavController().navigate(R.id.action_additionalData_to_additionalData,bundle)
            }else {
                findNavController().navigate(R.id.action_additionalData_to_photoFragment)
            }
        }
        additionalDataViewModel.error.observe(viewLifecycleOwner,{
            if(it != null){
                binding.additionalDataTextEdit.error = getString(it)
            }
            binding.additionalDataNext.isEnabled = it == null || it == errorCodeHigh

        })

        return binding.root
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param errorCode Parameter 1.
         * @param hint Parameter 2.
         * @param limitLow Parameter 3
         * @param limit Parameter 4
         * @return A new instance of fragment AdditionalData.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(errorCodeLow: Int,errorCodeHigh: Int, hint: Int,limitLow:Int,limit:Int) =
            AdditionalData().apply {
                arguments = Bundle().apply {
                    putInt(ERROR_CODE_LOW,errorCodeLow)
                    putInt(ERROR_CODE_HIGH,errorCodeHigh)
                    putInt(HINT, hint)
                    putInt(LIMIT_LOW,limitLow)
                    putInt(LIMIT,limit)
                }
            }
    }
}