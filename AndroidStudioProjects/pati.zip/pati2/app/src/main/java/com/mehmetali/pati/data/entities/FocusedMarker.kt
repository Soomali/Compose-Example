package com.mehmetali.pati.data.entities

import android.util.Log
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker

class FocusedMarkerState() {
    private var marker:Marker? = null
    private var shadows:MutableList<Marker>? = null
    private val markerPosition
    get() = marker?.position
    val hasFocused
    get() = marker != null && shadows!= null
    private val exceedLimit = 0.0075
    fun removeFocus(){
        if(hasFocused){
            marker = null
            for(i in shadows!!){
                i.remove()
            }
            shadows = null
        }
    }
    fun handleFocusedMarker(marker:Marker):Boolean{
        if(hasFocused){
            if(marker == this.marker){
                return true
            }
            for(i in 0 until shadows!!.size){
                if (shadows!![i] == marker){
                    val temp = shadows!![i]
                    shadows!![i] = this.marker!!
                    this.marker = temp
                    return false
                }
            }
        }
        return false
    }
    fun isAnimalAssociated(marker:Marker) = hasFocused && this.marker == marker || shadows!!.contains(marker)
    fun focus(marker: Marker){
        this.marker = marker
        this.shadows = mutableListOf()
    }
    fun addShadows(marker:Marker?){
        if(marker != null){
        this.shadows?.add(marker)
        }
    }
    fun tryRefocus(marker:Marker) : Boolean{
        if(this.marker != null && marker != this.marker && !shadows!!.contains(marker)){
            focus(marker)
            return true
        }
        return false
    }
    fun exceededLimit(position:LatLng) = markerPosition!!.exceeded(position,exceedLimit,exceedLimit)
    override fun toString(): String {
        return "position:$markerPosition, exceed Limit:latitude = ${markerPosition?.latitude ?: 0} ± $exceedLimit, longitude ${markerPosition?.longitude ?: 0} ± $exceedLimit"
    }
}

fun LatLng.exceeded(other:LatLng,latitudeExceedLimit:Double,longitudeExceedLimit:Double) :Boolean{
    //Log.d("[Exceeded Comparison]","${other.latitude > this.latitude + latitudeExceedLimit } > ${other.latitude} > ${this.latitude - latitudeExceedLimit}")
    if(other.latitude < this.latitude - latitudeExceedLimit || other.latitude > this.latitude + latitudeExceedLimit ) return true
    if(other.longitude < this.longitude - longitudeExceedLimit || other.longitude > this.longitude + longitudeExceedLimit ) return true

    return false
}