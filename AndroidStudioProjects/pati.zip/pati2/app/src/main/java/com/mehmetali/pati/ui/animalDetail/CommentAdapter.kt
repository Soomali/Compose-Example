package com.mehmetali.pati.ui.animalDetail

import android.content.Context
import android.content.Context.LAYOUT_INFLATER_SERVICE
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.lifecycle.LifecycleOwner
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.DocumentReference
import com.mehmetali.pati.data.client.getSubCommentCount
import com.mehmetali.pati.data.entities.*
import com.mehmetali.pati.data.entities.dataObjects.AnimalHolder
import com.mehmetali.pati.data.entities.dataObjects.SelfUser
import com.mehmetali.pati.databinding.CommentLayoutBinding
import com.mehmetali.pati.databinding.DialogHeaderBinding
import com.mehmetali.pati.ui.profile.ProfileActivity


//swaps the likeData if it presents, returns true if there is a likeData that has the same id as
//given [item], returns false otherwise
private fun MutableList<LikeDataHolder>.swapAtChange(item:LikeDataHolder):Boolean{
    for(i in 0 until this.size){
        if(this[i].id == item.id){
            if( this[i].isLike != item.isLike){
                this[i] = item
                 return true
            }
            break
        }
    }
    return false
}

fun setMarginOfLinearLayout(layout:LinearLayout,left:Int = 0,top:Int = 0,right:Int = 0,bottom:Int = 0)
{
    val params =  LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT)
    params.setMargins(
        left,top,right,bottom
    )
    layout.layoutParams = params
}


class BlockHolder{
    private val blocks= mutableListOf<String>()
    private val unBlocks= mutableListOf<String>()
    fun handleBlockEvent(user:DocumentReference,block:Boolean){
        if (block){
            unBlocks.remove(user.id)
            blocks.add(user.id)
        }else {
            blocks.remove(user.id)
            unBlocks.add(user.id)
        }
    }
    fun searchFor(user:DocumentReference):Boolean?{
         if( blocks.contains(user.id)){
             return true
         } else if(unBlocks.contains(user.id)) {
             return false
         }
        return null
    }
}


class CommentAdapter(private val applicationContext: Context,private val owner: LifecycleOwner,
                     private val dialogViewModel:DialogViewModel) :RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    private val items:MutableList<Comment> = animal.comments.value ?: mutableListOf()
    private var likedComments:MutableList<LikeDataHolder> = dialogViewModel.likedCommentsId.value?.toMutableList() ?: mutableListOf()
    private val animal get() = AnimalHolder.animal.value!!
    private val blockHolder = BlockHolder()
    init {
        Log.d("[CA likedComments]","$likedComments")
        //likedCommentsId is the users liked comments' id of that animal
        dialogViewModel.likedCommentsId.observe(owner,{
            Log.d("[CA likedComment]","$likedComments")
            var changed = false
            for (i in it){
                if(!likedComments.contains(i)){
                    likedComments.add(i)
                    changed = true
                }
                else if(likedComments.swapAtChange(i)){
                        changed = true
                }
            }
            if(changed) {
                notifyDataSetChanged()
            }
        })
        dialogViewModel.commentSendStatus.observe(owner,{
            if(it.second == -1){
                this.items.add(it.first as Comment)
                notifyItemInserted(itemCount + 1)
            }
            else{
                val comment = this.getComment(it.second - 1,items as MutableList<CommentData>)
                val value = comment.subComments.value ?: mutableListOf()
                value.add(it.first as SubComment)
                comment.subComments.value = value
                notifyItemInserted(it.second - 1)
            }
        })
    }


    private fun getComment(position: Int,comments:MutableList<CommentData>): CommentData {
        if (position == 0) return comments[0]
        var i = 1
        var count = getSubCommentCount(comments[0]) + 1
        var beforeCount = 0
        while (position - count >= 0) {
            beforeCount = count
            count +=  getSubCommentCount(comments[i]) + 1
            i++
        }
        return if(position - beforeCount == 0) comments[i - 1]
        else getComment(position - beforeCount - 1,comments[i - 1].subComments.value!! as MutableList<CommentData>)
    }

    override fun getItemViewType(position: Int): Int {
        return position
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType != 0) {
            val commentBinding = CommentLayoutBinding.inflate(LayoutInflater.from(parent.context))
            CommentViewHolder(commentBinding)
        } else {
            val inflater = applicationContext.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
            val binding = DialogHeaderBinding.inflate(inflater)
            HeaderHolder(binding)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if(position != 0){
            Log.d("[OBVH]","${this.itemCount}")
            val viewHolder = holder as CommentViewHolder
            val comment = getComment(position - 1,items as MutableList<CommentData>)
            comment.likedByUser = likedComments.singleOrNull {
                it.comment == comment.id
            }?.isLike
            comment.blocked = blockHolder.searchFor(comment.user) ?: false

            Log.d("[PST]","$position")
            Log.d("[OBVH]","${(comment as? SubComment)?.text}")
            viewHolder.bind(comment ,
                fun(like:Boolean?,view:View) {DialogViewModel.handleLikeEvent(comment,like,view)},
                onClickUser = {

                    val intent = Intent(applicationContext,ProfileActivity::class.java)
                    if(it.user != SelfUser.self.value!!.id){
                        SelfUser.shownUserUid.value = it.user
                    }
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    applicationContext.startActivity(intent,null)
                },
                onBlock = {
                          blockHolder.handleBlockEvent( it,true)
                          notifyDataSetChanged()
                },
                onUnblock = {
                    blockHolder.handleBlockEvent( it,false)
                            notifyDataSetChanged()
                },
            onDataRangeChange = { notifyItemRangeInserted(position + 1,it)})


            viewHolder.setAnswerOnClickListener {
                dialogViewModel.focusAt(comment,position,it)
            }
        }else{

            (holder as HeaderHolder).bind(applicationContext,owner,animal.photos,dialogViewModel)
        }
    }

    override fun getItemCount(): Int {
        var count = 1
        for(i in items){
            count += getSubCommentCount(i) + 1
        }
        Log.d("[CA count]","$count")
        return count
    }


    fun addNewItems(comments:Collection<Comment>){
        var hasChanged = false
        for (i in comments){
            if (!items.contains(i)){
                items.add(i)
                hasChanged = true
            }
        }
        if (hasChanged) notifyDataSetChanged()
    }
}





/*
*     override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        if(p1 == null) {
            val inflater = p2?.context?.
            getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            val binding = CommentLayoutBinding.inflate(inflater)
            for (i in 0 until (p0 + 4).rem(4) + 1){
                val view = View(applicationContext)
                val params = LinearLayout.LayoutParams(5,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                params.setMargins(10,0,10,0)
                view.layoutParams = params
                view.setBackgroundColor(Color.MAGENTA)
                binding.commentLayout.addView(view,i)
            }
            return binding.root
        }
        return p1
    }
*
* */
