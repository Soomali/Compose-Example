package com.mehmetali.pati.data.entities.dataObjects

import androidx.lifecycle.MutableLiveData
import com.mehmetali.pati.data.entities.Animal

object AnimalHolder {
    var animal: MutableLiveData<Animal> = MutableLiveData()
}