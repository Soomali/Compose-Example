package com.mehmetali.pati.ui.signUp.mailPassword

data class SignUpFormState(
    val usernameError: Int? = null,
    val passwordError: Int? = null,
    val isDataValid: Boolean = false
)