package com.mehmetali.pati.ui.fragmentHolder.ui.map

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.navigation.fragment.findNavController
import com.mehmetali.pati.R
import com.mehmetali.pati.databinding.LocationPermissionDeniedBinding

class PermissionFragment : Fragment() {
    private lateinit var binding : LocationPermissionDeniedBinding
    private var locationPermissionGranted:Boolean = false
    private val permissionResult : ActivityResultLauncher<String> = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        if(it){
            this.findNavController().navigate(R.id.action_permissionFragment_to_mapsFragment)
        }
        showUI()
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        locationPermissionGranted = hasPermissions(requireContext(),arrayOf(Manifest.permission.ACCESS_FINE_LOCATION))
        if(!locationPermissionGranted){
            hideUI()
            permissionResult.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        else {
            findNavController().navigate(R.id.action_permissionFragment_to_mapsFragment)
        }
        binding = LocationPermissionDeniedBinding.inflate(layoutInflater)
        binding.button.setOnClickListener {
            hideUI()
            permissionResult.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        // Inflate the layout for this fragment
        return binding.root
    }

    private fun hideUI(){
        binding.requestTextView.visibility = View.GONE
        binding.button.visibility = View.GONE
    }
    private fun showUI(){
        binding.requestTextView.visibility = View.VISIBLE
        binding.button.visibility = View.VISIBLE
    }

    private fun hasPermissions(context: Context, permissions: Array<String>): Boolean = permissions.all {
        ActivityCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
    }


}

