package com.mehmetali.pati.ui.signUp.additionalData

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class AdditionalDataViewModel(private val errorCodeLow:Int,
                              private val errorCodeHigh:Int,
                              private val lowLimit:Int = 0,
                              private val limit:Int = 255): ViewModel() {
    private val _error = MutableLiveData<Int?>()
    val error:LiveData<Int?> = _error

    fun setOnTextChangedData(text:String){
        when {
            text.length < lowLimit -> {
                _error.value = errorCodeLow
            }
            text.length >= limit -> {
                _error.value = errorCodeHigh
            }
            else -> {
                _error.value = null
            }
        }
    }
}