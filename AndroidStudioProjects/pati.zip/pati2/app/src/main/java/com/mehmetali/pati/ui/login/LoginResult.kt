package com.mehmetali.pati.ui.login

import com.mehmetali.pati.data.entities.User

/**
 * Authentication result : success (user details) or error message.
 */
data class LoginResult(
    val success: User? = null,
    val error: Int? = null
)