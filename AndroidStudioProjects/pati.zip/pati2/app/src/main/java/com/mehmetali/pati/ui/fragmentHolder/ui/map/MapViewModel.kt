package com.mehmetali.pati.ui.fragmentHolder.ui.map

import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.firebase.geofire.GeoFireUtils
import com.firebase.geofire.GeoLocation
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.GeoPoint
import com.mehmetali.pati.data.client.createUser
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import com.mehmetali.pati.data.client.createAnimal
import com.mehmetali.pati.data.client.createComment
import com.mehmetali.pati.data.client.createSubComment
import com.mehmetali.pati.data.entities.*
import com.mehmetali.pati.data.entities.dataObjects.SelfUser
import org.imperiumlabs.geofirestore.GeoFirestore
import org.imperiumlabs.geofirestore.listeners.GeoQueryDataEventListener
import org.imperiumlabs.geofirestore.listeners.GeoQueryEventListener
import org.w3c.dom.Document
import java.lang.ref.Reference
import kotlin.collections.HashMap


@RequiresApi(Build.VERSION_CODES.O)
class MapViewModel: ViewModel() {
    private var userPos = MutableLiveData<GeoPoint>()

    private val  firebaseInstance = FirebaseFirestore.getInstance()
    private val animals:MutableLiveData<List<Animal>> by lazy {
        MutableLiveData<List<Animal>>().also {
            fetchAnimals()
        }
    }
    init {
        SelfUser.self =MutableLiveData<User>().also {
            if(SelfUser.uid != null) {
                initSelf()
            }
        }
    }
    fun getSelfPos():LiveData<GeoPoint> = userPos
    fun getAnimals():LiveData<List<Animal>>{
        return animals
    }
    fun getSelf():LiveData<User> {
        return SelfUser.self
    }

    private fun initSelf(){
        firebaseInstance.collection("Users").document(SelfUser.uid!!).get().addOnCompleteListener {
            val data = it.result!!.data!!
            val userData = createUser(data,isSelf = true,documentReference = firebaseInstance.collection("Users").document(
                SelfUser.uid!!))
            SelfUser.self.postValue(userData)
        }
    }
    fun postToUserPosition(lat:Double,long:Double){
        userPos.postValue(GeoPoint(lat,long))
    }
    private fun addDummyAnimalPosition(){
        val lat = 51.5070
        val lng = 0.1277
        val hash = GeoFireUtils.getGeoHashForLocation(GeoLocation(lat, lng))
        val updates: MutableMap<String, Any> = HashMap()
        updates["seenPositions"] = mutableListOf<HashMap<String,Any>>()
        var geoPoint = HashMap<String,Any>()
        geoPoint["geoHash"] = hash
        geoPoint["point"] = GeoPoint(lat, lng)
        (updates["seenPositions"] as MutableList<HashMap<String,Any>>).add(geoPoint)
        firebaseInstance.collection("Animals").document("G3TLtHnWYq9SrHQR15bx").get().addOnSuccessListener {

            val positions = (updates["seenPositions"] as MutableList<HashMap<*,*>>).addAll(it!!.data!!["seenPositions"] as List<HashMap<String,Any>>)
            firebaseInstance.collection("Animals").document("G3TLtHnWYq9SrHQR15bx").update(updates).addOnCompleteListener {
                Log.d("[Update]","updated animal,go check it LoL")
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun fetchAnimals() {
        /*
            TODO:find a way to fetch nearby animals to user.
            TODO:find a way to add animal.
        */
        val geo = GeoFirestore(firebaseInstance.collection("Animals"))
        val animals = mutableListOf<Animal>()
        Log.d("[ABBBBBBBOOOO]","${userPos.value}")
        geo.queryAtLocation(userPos.value!!,0.2)
            . addGeoQueryDataEventListener(object:GeoQueryDataEventListener{
            override fun onDocumentChanged(documentSnapshot: DocumentSnapshot, location: GeoPoint) {
                //
            }
            override fun onDocumentEntered(documentSnapshot: DocumentSnapshot, location: GeoPoint) {
                Log.d(  "[Doc]","${documentSnapshot.data}")
                val data = documentSnapshot.data!!
                val seenPositions = data["seenPositions"] as List<HashMap<String,Any>>
                val seenPositionsGeoPoint = seenPositions.map { position ->
                    position["point"]
                } as List<GeoPoint>
                val animal = createAnimal(data,documentSnapshot.reference,seenPositionsGeoPoint)
                documentSnapshot.reference.collection("Photos").limit(5).orderBy("votes").get().addOnSuccessListener { tit ->
                    try {
                        val animalPhotos = mutableListOf<AnimalPhoto>()
                        for (i in tit.documents){
                            val data = i.data!!
                            val animalPhoto = AnimalPhoto(photo = data["photoUrl"] as String,votes = data["votes"] as Long,putUser = data["user"] as DocumentReference)
                            Log.d("[Photo]", tit.documents[0].data.toString())
                            animalPhotos.add(animalPhoto)
                        }
                        Log.d("[Animal Photo Data]","Posted")
                        animal.photos.postValue(animalPhotos)
                    } catch (e:Exception) {
                        Log.e("[Error]","${e.localizedMessage}")
                    }
                }
                animals.add(animal)
            }

            override fun onDocumentExited(documentSnapshot: DocumentSnapshot) {
                //
            }

            override fun onDocumentMoved(documentSnapshot: DocumentSnapshot, location: GeoPoint) {
                //TODO("Not yet implemented")
            }

            override fun onGeoQueryError(exception: Exception) {
                //TODO("Not yet implemented")
            }

            override fun onGeoQueryReady() {
                this@MapViewModel.animals.postValue(animals)
            }
        })
    }



    companion object{
        fun fetchAnimalData(anim:Animal, requestData:MutableLiveData<Pair<Int,Int>>) {
            requestData.value =  1 to 0
            Log.d("[Fetching Data]", "Started Fetching data")
            anim.id.collection("Names").limit(30).orderBy("points").get().addOnSuccessListener {
                Log.d("[NameData]", "Successfully fetched nameData of $anim")
                val docs = it.documents
                val names = mutableListOf<AnimalName>()
                for (i in docs) {
                    val data = i.data!!
                    val user = data["user"] as DocumentReference
                    names.add(AnimalName(
                                    i.reference,
                                    user,
                                    data["name"] as String,
                                    data["points"] as Long))
                }
                anim.names.postValue(names)

            }



            anim.id.collection("Comments").limit(SelfUser.commentLimit / 3).get().addOnSuccessListener {
                    Log.d("[CommentData]","Successfully fetched commentData of $anim")
                    val docs = it.documents
                    val comments = mutableListOf<Comment>()
                    requestData.value = docs.size to 0
                    val blockeds = mutableListOf<Pair<DocumentReference,Boolean>>()
                    for(i in docs){
                        Log.d("[CommentData]","${i.data}")
                        val userRef = i.data!!["user"] as DocumentReference
                        fun completeComment(blocked:Boolean){
                            val data = i.data!!
                            val comment = createComment(i.reference,data,userRef)
                            comment.blocked = blocked
                            val x = initComment(comment.id,comment,anim,requestData = requestData,blockeds)
                            Log.d("[Data]","$x")
                            comments.add(comment)
                        }

                        val blockedData = blockeds.firstOrNull{h -> h.first == userRef }
                        if( blockedData == null){
                            SelfUser.self.value!!.id!!.collection("BlockedUsers").document(userRef.id).get().addOnSuccessListener { tit ->
                                if(!tit.exists()){
                                    completeComment(false)
                                    blockeds.add(userRef to false)
                                }else{
                                    completeComment(true)
                                    blockeds.add(userRef to true)
                                }
                            }
                        }else{
                            completeComment(blockedData.second)
                        }
                    }

                    if(anim.comments.value.isNullOrEmpty()){
                        anim.comments.postValue(comments)

                    }else{
                        comments.addNews(anim.comments.value!!)
                        anim.comments.value = comments
                    }
                }

        }
        private fun getLimit(count:Int) =(22 / ((count * count) - (3 * count) + 4)).toLong()
        private fun initComment(
            commentRef:DocumentReference,
            commentData: CommentData,
            anim: Animal,
            requestData: MutableLiveData<Pair<Int, Int>>,
            blockeds:MutableList<Pair<DocumentReference,Boolean>>,
            count:Int = 1,){
            Log.d("[MV initCommentData]"," ${requestData.value?.first} to ${requestData.value?.second} -- ${commentData.text}")
            var subComments: MutableList<SubComment>?

            fun addToReqData(first:Int = 0,second:Int = 0){
                val value  = requestData.value!!
                requestData.value  = value.first + first  to value.second + second
            }
            val limit = getLimit(count)
            Log.d("[initComment]","$limit")
            if(count < 8 ){
                commentRef.collection("Comments").limit(limit).get().addOnSuccessListener {
                    if(!it.isEmpty){
                        subComments = mutableListOf()
                        addToReqData(first = it.documents.size)
                        for (i in it.documents){
                            val userRef = i.data!!["user"] as DocumentReference
                            fun completeComment(blocked:Boolean) {
                                val data = i.data!!
                                val comment = createSubComment(i.reference, data, userRef, count)
                                comment.blocked = blocked
                                subComments!!.add(comment)
                                initComment(comment.id, comment, anim, requestData, blockeds,count + 1)
                            }

                            val blockedData = blockeds.firstOrNull {h ->  h.first == userRef }
                            if( blockedData == null){
                                SelfUser.self.value!!.id!!.collection("BlockedUsers").document(userRef.id).get().addOnSuccessListener { tit ->
                                    if(!tit.exists()){
                                        completeComment(false)
                                        blockeds.add(userRef to false)
                                    }else{
                                        completeComment(true)
                                        blockeds.add(userRef to true)
                                    }
                                }
                            }else{
                                completeComment(blockedData.second)
                            }
                        }
                        commentData.subComments.postValue(subComments)
                        addToReqData(second = 1)

                    }
                    else {
                        addToReqData(second = 1)
                    }
                }.addOnCompleteListener {
                    Log.d("[MVM CompletedInit]","cancelled:${it.isCanceled},error:${it.exception?.localizedMessage},result:${it.result?.isEmpty},success:${it.isSuccessful}")
                }


            }
        }

    }

//2 2 4 8

}

fun MutableList<Comment>.addNews(news:Collection<Comment>){
    for(i in news){
        if (!this.contains(i)){
            this.add(i)
        }
    }
}