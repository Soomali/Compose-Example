package com.mehmetali.pati.ui.animalDetail

import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.util.Log
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.widget.PopupMenu
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomViewTarget
import com.bumptech.glide.request.transition.Transition
import com.google.firebase.firestore.DocumentReference
import com.mehmetali.pati.R
import com.mehmetali.pati.data.client.blockUser
import com.mehmetali.pati.data.client.getSubCommentCount
import com.mehmetali.pati.data.client.setVisibilityOfSubComments
import com.mehmetali.pati.data.client.unBlockUser
import com.mehmetali.pati.data.entities.Comment
import com.mehmetali.pati.data.entities.CommentData
import com.mehmetali.pati.data.entities.SubComment
import com.mehmetali.pati.data.entities.dataObjects.CommentPhotoResolver
import com.mehmetali.pati.data.entities.dataObjects.SelfUser
import com.mehmetali.pati.databinding.CommentLayoutBinding
import com.mikhaellopez.circularimageview.CircularImageView

class CommentViewHolder(private val commentView: CommentLayoutBinding) : RecyclerView.ViewHolder(commentView.root) {
    var separated = false
    private var isPutByUser = false
    private lateinit var onBlock: (DocumentReference) -> Unit
    private lateinit var onUnblock: (DocumentReference) -> Unit
    private lateinit var commentData: CommentData
    private fun loadIntoUserImage(url:String,user: DocumentReference){
        Glide.with(commentView.userImage).
        asBitmap().
        load(url).
        placeholder(R.drawable.ic_launcher_foreground).
        into(object: CustomViewTarget<CircularImageView, Bitmap>(commentView.userImage){
            override fun onLoadFailed(errorDrawable: Drawable?) {
                commentView.userImage.setImageDrawable(errorDrawable)
            }

            override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                commentView.userImage.setImageBitmap(resource)
                CommentPhotoResolver.add(user, resource)
            }

            override fun onResourceCleared(placeholder: Drawable?) {
                Log.d("[CA resourceCleared]", "cleared ${user.id} photo.")
            }

        })

    }
    private fun setOnLikeListeners(commentData: CommentData, likeEventHandler:(Boolean?, View) -> Unit){

        commentView.likeButton.setOnClickListener {
            if(commentData.likedByUser == true) {
                commentData.likedByUser = null
                commentData.likes--
            }
            else{
                if(commentData.likedByUser == false) commentData.dislikes--
                commentData.likedByUser = true
                commentData.likes++

            }
            commentView.likeLayout.isEnabled = false
            likeEventHandler(commentData.likedByUser,
                commentView.likeLayout)
            handleLikeEventUi(commentData)
        }
        commentView.dislikeButton.setOnClickListener {
            if(commentData.likedByUser == false) {
                commentData.likedByUser = null
                commentData.dislikes--
            }
            else{
                if(commentData.likedByUser == true) commentData.likes--
                commentData.likedByUser = false
                commentData.dislikes++
            }

            commentView.likeLayout.isEnabled = false
            likeEventHandler(commentData.likedByUser,
                commentView.likeLayout)
            handleLikeEventUi(commentData)
        }

    }


    fun bind(commentData: CommentData,
             likeEventHandler:(Boolean?, View) -> Unit,
             onClickUser:((CommentData) -> Unit)?,
             onBlock:(DocumentReference) -> Unit,
             onUnblock:(DocumentReference) -> Unit,
             onDataRangeChange:((Int) -> Unit)? = null,
    ){
        this.onBlock = onBlock
        this.onUnblock = onUnblock
        this.commentData = commentData
        isPutByUser = commentData.user == SelfUser.self.value!!.id!!
        if (commentData.photo != ""){
            if(!CommentPhotoResolver.contains(commentData.user)){
                loadIntoUserImage(commentData.photo,commentData.user)
            }
            else{
                commentView.userImage.setImageBitmap(CommentPhotoResolver.get(commentData.user)!!)
            }
        }else{
            commentView.userImage.setImageResource(R.drawable.ic_launcher_foreground)
        }

            if (onClickUser != null) {
                Log.d("[OCUDT]", "OnclickUser:$onClickUser")
                commentView.userDataLayout.setOnClickListener {
                    Log.d("[HCBA]", "Clicked to ${commentData.username}")
                    onClickUser(commentData)
                }
            }

            setOnLikeListeners(commentData, likeEventHandler)

            commentView.comment.text = commentData.text
            if (!separated && commentData is Comment) {
                separated = true
                setMarginOfLinearLayout(commentView.commentLayout, 0, 25)
            }



            if (commentData is SubComment) {
                setMarginOfLinearLayout(commentView.commentLayout)
                if (!separated && !commentData.subComments.value.isNullOrEmpty() && commentData.subComments.value!!.any { !it.isVisible }) {
                    val v = LayoutInflater.from(commentView.root.context).inflate(
                        R.layout.see_more_view, commentView.separatorContainer, false
                    )
                    commentView.dataLayout.addView(v)
                    v.setOnClickListener {
                        commentView.dataLayout.removeView(v)
                        commentView.dataLayout.invalidate()
                        setVisibilityOfSubComments(commentData, depth = 3)
                        val size = getSubCommentCount(commentData)
                        Log.d("[CA Size]", "$size")
                        onDataRangeChange!!(size)

                    }
                }
                if (!separated) {
                    Log.d("[CommentDataPlace]", "${commentData.place} for ${commentData.text}")
                    for (i in 0 until commentData.place) {
                        addSeparator()
                    }
                    separated = true
                }
            }
            handleLikeEventUi(commentData)
        if(commentData.blocked){
            blockUI()
        }else{
            unBlockUI()
        }
        commentView.commentOptionsButton.setOnClickListener {
            showPopup(it)
        }
    }
    private fun blockUI(){
        commentView.comment.visibility = View.GONE
        commentView.likeLayout.visibility = View.GONE
        commentView.name.text = "Bu hesap engellenmiş."
        commentView.userImage.visibility = View.GONE

    }

    private fun unBlockUI(){
        commentView.userImage.visibility = View.VISIBLE
        commentView.comment.visibility = View.VISIBLE
        commentView.likeLayout.visibility = View.VISIBLE
        commentView.name.text = commentData.username

    }

    fun setAnswerOnClickListener(listener:(binding: CommentLayoutBinding) -> Unit){
        commentView.answer.setOnClickListener {
            listener(commentView)
        }
    }

    private fun handleLikeEventUi(commentData: CommentData){
        commentView.likes.text = "${commentData.likes}"
        commentView.dislikes.text = "${commentData.dislikes}"
        when(commentData.likedByUser){
            true -> {
                commentView.likeButton.setColorFilter(R.color.teal_200, android.graphics.PorterDuff.Mode.SRC_IN)
                commentView.dislikeButton.setColorFilter(R.color.black, android.graphics.PorterDuff.Mode.SRC_IN)
            }
            false -> {
                commentView.dislikeButton.setColorFilter(R.color.teal_200, android.graphics.PorterDuff.Mode.SRC_IN)
                commentView.likeButton.setColorFilter(R.color.black, android.graphics.PorterDuff.Mode.SRC_IN)
            }
            else -> {
                commentView.likeButton.setColorFilter(R.color.black, android.graphics.PorterDuff.Mode.SRC_IN)
                commentView.dislikeButton.setColorFilter(R.color.black, android.graphics.PorterDuff.Mode.SRC_IN)
            }
        }
    }

    private fun addSeparator(){
                val v = LayoutInflater.from(commentView.root.context).inflate(
                    R.layout.seperator_view,commentView.separatorContainer,false
                )
                commentView.separatorContainer.addView(v)
    }

    private fun showPopup(view: View,
    ) {
        val popup = PopupMenu(view.context, view)
        popup.inflate(if(!isPutByUser)
                            if(commentData.blocked) R.menu.image_options_blocked_menu
                            else R.menu.image_options_menu
                      else R.menu.image_options_self_menu
        )

        popup.setOnMenuItemClickListener(PopupMenu.OnMenuItemClickListener { item: MenuItem? ->
            when (item!!.itemId) {
                R.id.report -> {
                    Toast.makeText(view.context, "MAAAAAAAAAAAAA", Toast.LENGTH_LONG).show()
                }
                R.id.block -> {
                    blockUser(commentData.user) {
                        blockUI()
                        commentData.blocked = true
                        onBlock(commentData.user)
                    }
                }
                R.id.unblock -> {
                    unBlockUser(commentData.user) {
                        unBlockUI()
                        commentData.blocked = false
                        onUnblock(commentData.user)
                    }
                }
                R.id.show -> {
                    unBlockUI()
                }
                R.id.delete -> {
                    Toast.makeText(view.context, "DELETEEEEEEEEEEEEEEEEEEEEEEEE", Toast.LENGTH_LONG)
                        .show()
                }
            }
            true
        })
        popup.show()
    }

}