package com.mehmetali.pati.ui.animalDetail

import android.content.Context
import android.graphics.Color
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.MutableLiveData
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.PagerSnapHelper
import androidx.recyclerview.widget.RecyclerView
import com.mehmetali.pati.data.entities.AnimalName
import com.mehmetali.pati.data.entities.AnimalPhoto
import com.mehmetali.pati.data.entities.dataObjects.AnimalHolder
import com.mehmetali.pati.databinding.AnimalNameBinding
import com.mehmetali.pati.databinding.DialogHeaderBinding


//TODO Find a way to add image [NEEDS_BACKEND_IMPLEMENTATION] and names [NEEDS_FULL_IMPLEMENTATION] into animals.
//Also find a way to report animals and comments. [NEEDS_BACKEND_IMPLEMENTATION]
//Set an option to delete names and images if put by user.[NEEDS_BACKEND_IMPLEMENTATION]
//find a way to rate an animal.[NEEDS_FULL_IMPLEMENTATION]




class HeaderHolder(private val binding: DialogHeaderBinding,
): RecyclerView.ViewHolder(binding.root){
    private val nameManager =  AnimalNameManager()

    init {
        val snapHelper = PagerSnapHelper()
        snapHelper.attachToRecyclerView(binding.imageList)

    }

    fun bind(
        applicationContext: Context,
        lifecycleOwner: LifecycleOwner,
        photos: MutableLiveData<MutableList<AnimalPhoto>>,
        dialogViewModel: DialogViewModel){

        val recyclerView: RecyclerView = binding.imageList
        val adapter = ImageAdapter(lifecycleOwner, photos)

        binding.behaviourRating.rating = AnimalHolder.animal.value!!.behaviour.toFloat()
        binding.conditionRating.rating = AnimalHolder.animal.value!!.condition.toFloat()

        recyclerView.layoutManager = LinearLayoutManager(applicationContext)
        recyclerView.adapter = adapter
        dialogViewModel.likedNamesID.observe(lifecycleOwner){ tit ->

            fun addTo(name: AnimalName, pos:Int): View {
                name.likedByUser = tit.contains(name.id)
                return getNameView(name,pos,applicationContext)
            }

            AnimalHolder.animal.value!!.names.observe(lifecycleOwner,{
                nameManager.addNews(it.toList())
                nameManager.addTo(binding.nameLayout,
                    {name,pos ->
                        addTo(name,pos)
                    },
                    {binding.seeMore.visibility = View.VISIBLE })
            })
            binding.seeMore.setOnClickListener {
                binding.seeMore.visibility = View.GONE
                nameManager.addTo(binding.nameLayout,
                    {name,pos -> addTo(name,pos)},
                    {binding.seeMore.visibility = View.VISIBLE })
            }
        }

    }


    private fun getNameView(name: AnimalName, position: Int,applicationContext: Context): View {
        val nameBinding = AnimalNameBinding.inflate(LayoutInflater.from(applicationContext))
        nameBinding.nameView.text = name.name

        val points =" (${name.vote} puan)"
        nameBinding.PointView.text =points

        if(position < 10){
            val size = 22 - (position * 0.5).toFloat()
            nameBinding.nameView.setTextSize(TypedValue.COMPLEX_UNIT_SP,size)
            nameBinding.PointView.setTextSize(TypedValue.COMPLEX_UNIT_SP,size - 2)
        }else{
            nameBinding.nameView.setTextSize(TypedValue.COMPLEX_UNIT_SP,12f)
            nameBinding.PointView.setTextSize(TypedValue.COMPLEX_UNIT_SP,10f)
        }
        if (name.likedByUser){
            nameBinding.PointView.setTextColor(Color.CYAN)
        }

        nameBinding.layout.setOnClickListener {
                if(name.likedByUser){
                    name.vote--

                }else{
                    name.vote++

                }
                name.likedByUser = !name.likedByUser
                val updPoints =" (${name.vote} puan)"
                nameBinding.PointView.text = updPoints
            DialogViewModel.handleVoteEvent(name, name.likedByUser, it)

            }

        return nameBinding.root
    }
}