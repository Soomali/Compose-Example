package com.mehmetali.pati.ui.animalDetail

import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.util.DisplayMetrics
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.RelativeLayout
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.MutableLiveData
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearSmoothScroller
import androidx.recyclerview.widget.RecyclerView.SmoothScroller
import com.mehmetali.pati.data.entities.dataObjects.AnimalHolder
import com.mehmetali.pati.databinding.ActivityDialogBinding
import com.mehmetali.pati.ui.fragmentHolder.ui.map.MapViewModel

class AnimalDialog : AppCompatActivity() {
    private lateinit var  binding: ActivityDialogBinding
    private lateinit var  dialogViewModel: DialogViewModel
    private lateinit var  touchEvent:MotionEvent
    @RequiresApi(Build.VERSION_CODES.R)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDialogBinding.inflate(layoutInflater)
        val layoutManager = LinearLayoutManager(applicationContext)
        val smoothScroller: SmoothScroller = object : LinearSmoothScroller(applicationContext) {
            override fun getVerticalSnapPreference(): Int {
                return SNAP_TO_START
            }

            override fun calculateDtToFit(
                viewStart: Int,
                viewEnd: Int,
                boxStart: Int,
                boxEnd: Int,
                snapPreference: Int
            ): Int {
                return (boxStart + (boxEnd - boxStart) / 2) - (viewStart + (viewEnd - viewStart) / 2);
            }
        }
        val downTime = SystemClock.uptimeMillis()
        touchEvent = MotionEvent.obtain(downTime,downTime + 100,MotionEvent.ACTION_UP,0f,0f,0)


        dialogViewModel = DialogViewModel(fun(){focusToComment()},layoutManager,
            smoothScroller as LinearSmoothScroller
        )






        val x = DisplayMetrics()
        applicationContext.display?.getRealMetrics(x)
        Log.d("[Metrics]","${x.widthPixels} to ${x.heightPixels}")
        binding.dialogParent.layoutParams = RelativeLayout.LayoutParams(
            (x.widthPixels * 0.9).toInt(),(x.heightPixels *0.8).toInt()
        )
        setContentView(binding.root)
        val adapter = CommentAdapter(applicationContext,this,dialogViewModel)
        binding.dataView.layoutManager = layoutManager
        val request = MutableLiveData(4 to 0)
        MapViewModel.fetchAnimalData(AnimalHolder.animal.value!!,request)
        request.observe(this,{
            if (it.first == it.second){
                binding.progressView.progressBar.visibility = View.GONE
                adapter.addNewItems(AnimalHolder.animal.value!!.comments.value!!.toList())
            }
        })

        binding.dataView.adapter = adapter
        binding.commentAddText.onFocusChangeListener =
            View.OnFocusChangeListener { _, p1 ->
                Log.d("[AD Focus]","$p1")
                if(!p1) dialogViewModel.commentParent = null
            }
        binding.commentSendButton.setOnClickListener {
            dialogViewModel.commentTo(binding.commentAddText.text.toString())
            binding.commentAddText.setText("")
        }

    }


    private fun focusToComment(){
        binding.commentAddText.isFocusableInTouchMode = true
        binding.commentAddText.requestFocus()
        binding.commentAddText.dispatchTouchEvent(touchEvent)

    }
    override fun onDestroy() {
        AnimalHolder.animal.value?.comments?.value?.clear()
        AnimalHolder.animal.value?.names?.value?.clear()

        super.onDestroy()
    }

    override fun onBackPressed() {
        dialogViewModel.unFocus()
        super.onBackPressed()
    }
}
